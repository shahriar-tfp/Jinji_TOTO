Imports System.Data
Partial Class Pages_AdHoc_Reports_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim dt As New DataTable
            dt.Columns.Add("EmpID")
            dt.Columns.Add("Reasons")
            Session("dt") = dt
            dgTest.DataSource = Session("dt")
            dgTest.DataBind()
        End If
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim dr As DataRow = CType(Session("dt"), DataTable).NewRow
        dr(0) = txt1.Text
        dr(1) = txt2.Text
        CType(Session("dt"), DataTable).Rows.Add(dr)
        CType(Session("dt"), DataTable).AcceptChanges()
        dgTest.DataSource = Session("dt")
        dgTest.DataBind()
    End Sub
End Class
